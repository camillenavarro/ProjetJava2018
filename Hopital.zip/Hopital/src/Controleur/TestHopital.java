/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controleur;

/**
 *
 * @author Rim
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.awt.event.*;
import java.awt.*;
import java.util.*;
import javax.swing.*;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class TestHopital {

    static final String NAME = "hopital";
    static final String LOGIN = "root";
    static final String PASSWORD = null;

    public static void main(String[] args) {

        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        
        //private Connexion maconnexion;

        try {
            try {
                Connexion maconnexion = new Connexion(NAME, LOGIN, PASSWORD);

                resultSet = statement.executeQuery("SELECT nom, prenom FROM `malade` WHERE mutuelle = \"MAAF\";");
                while (resultSet.next()) {
                System.out.printf("%s\t%s\t%s\t%f\n",
                resultSet.getString(1),
                resultSet.getString(2),
                resultSet.getString(3),
                resultSet.getFloat(4));
            }
            }
            catch (SQLException ex) {
            }

        } catch (ClassNotFoundException e) {
            } //finally {
                //try {
                //    resultSet.close();
                //    statement.close();
                //    connection.close();
                //} catch (SQLException ex) {
            //}
        //}
    }
    
}
